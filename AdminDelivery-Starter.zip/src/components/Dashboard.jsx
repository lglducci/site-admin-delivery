
function Dashboard() {
  return (
    <div className="flex items-center justify-center h-screen bg-green-100">
      <h2 className="text-3xl font-bold">Bem-vindo ao Painel Admin Delivery</h2>
    </div>
  );
}

export default Dashboard;
